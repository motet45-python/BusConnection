# 🚌 BusConnect — Application Flask de réservation de bus

Projet Flask d'évaluation — Système de réservation de bus interurbains au Cameroun.

---

## 🗂️ Structure du projet

```
busconnect/
│
├── app.py                        # Point d'entrée : factory create_app() + seed data
├── config.py                     # Configuration (Dev / Prod)
├── extensions.py                 # Instances Flask-SQLAlchemy, Login, Cache, CSRF
├── models.py                     # Modèles SQLAlchemy (Utilisateur, Agence, Bus, Trajet, Voyage, Réservation)
│
├── functions/                    # Logique métier — 1 fichier = 1 domaine fonctionnel
│   ├── __init__.py
│   ├── disponibilite.py          # Vérification / réservation / libération de places (verrou atomique)
│   ├── ticket.py                 # Génération numéro unique + QR code base64
│   ├── annulation.py             # Politique de remboursement (100% / 50% / 0%)
│   ├── recherche_trajet.py       # Algorithme BFS pour trajets avec correspondances
│   ├── cache_utils.py            # Mise en cache des trajets et voyages (Flask-Caching)
│   └── dashboard.py             # Calcul des métriques : recettes, taux de remplissage, top trajets
│
├── routes/                       # Blueprints Flask — 1 fichier = 1 fonctionnalité
│   ├── __init__.py
│   ├── main.py                   # Accueil + recherche de trajets
│   ├── auth.py                   # Connexion, inscription, déconnexion
│   ├── agences.py                # CRUD agences (admin)
│   ├── bus.py                    # CRUD bus (agent/admin)
│   ├── trajets.py                # CRUD trajets (agent/admin)
│   ├── voyages.py                # CRUD voyages planifiés (agent/admin)
│   ├── reservations.py           # Réservation, annulation, ticket, mes réservations
│   └── dashboard.py              # Tableau de bord agence
│
├── static/
│   ├── css/
│   │   └── style.css             # Feuille de style complète (blanc, noir, bleu-clair, rouge)
│   └── js/
│       └── main.js               # JavaScript : navbar, alertes, classe selector, graphiques, filtres
│
├── templates/
│   ├── base.html                 # Layout principal (navbar + footer + flash messages)
│   ├── index.html                # Page d'accueil avec moteur de recherche
│   ├── auth/
│   │   ├── login.html
│   │   └── register.html
│   ├── trajets/
│   │   ├── liste.html
│   │   ├── form.html
│   │   └── recherche.html        # Résultats + itinéraires avec correspondances
│   ├── voyages/
│   │   ├── liste.html
│   │   └── form.html
│   ├── reservations/
│   │   ├── formulaire.html       # Sélecteur de classe Classique / VIP
│   │   ├── ticket.html           # Ticket avec QR code
│   │   ├── annulation.html       # Confirmation avec montant remboursable
│   │   └── liste.html            # Mes réservations
│   ├── agences/
│   │   ├── liste.html
│   │   └── form.html
│   ├── bus/
│   │   ├── liste.html
│   │   └── form.html
│   └── dashboard/
│       └── agence.html           # Stats + graphiques Chart.js + taux de remplissage
│
├── tests/
│   ├── __init__.py
│   └── test_reservations.py      # Tests Pytest (disponibilité, ticket, annulation, BFS)
│
├── requirements.txt
├── .env.example
└── README.md
```

---

## ⚙️ Installation

```bash
# 1. Cloner ou décompresser le projet
cd busconnect

# 2. Créer et activer un environnement virtuel
python -m venv venv
source venv/bin/activate        # Linux / Mac
venv\Scripts\activate           # Windows

# 3. Installer les dépendances
pip install -r requirements.txt

# 4. Configurer les variables d'environnement
cp .env.example .env
# (Editez .env si nécessaire)

# 5. Lancer l'application
python app.py
```

Accédez à [http://localhost:5000](http://localhost:5000)

---

## 👤 Comptes de test (créés automatiquement)

| Rôle   | Email                    | Mot de passe |
|--------|--------------------------|--------------|
| Admin  | admin@busconnect.cm      | admin123     |
| Agent  | agent@busconnect.cm      | agent123     |
| Client | jean@example.cm          | client123    |

---

## 🧪 Lancer les tests

```bash
pytest tests/ -v
```

---

## 🎨 Palette de couleurs

| Couleur     | Variable CSS       | Code hex  |
|-------------|-------------------|-----------|
| Blanc       | `--blanc`          | `#FFFFFF` |
| Noir        | `--noir`           | `#1A1A1A` |
| Bleu-clair  | `--bleu`           | `#3AB4F2` |
| Rouge       | `--rouge`          | `#E63946` |

---

## 🔑 Fonctionnalités principales

- **Recherche de trajets** : voyages directs (avec cache) + correspondances via BFS
- **Réservation** : sélection classe Classique/VIP, verrou atomique anti-surréservation
- **Ticket numérique** : numéro unique `BC-YYYYMMDD-XXXX` + QR code base64 imprimable
- **Annulation** : politique de remboursement (100% > 48h / 50% entre 24-48h / 0% < 24h)
- **Dashboard agence** : recettes, taux de remplissage, graphiques Chart.js
- **Gestion complète** : Agences, Bus, Trajets, Voyages (CRUD protégé par rôle)
- **Authentification** : Flask-Login avec rôles client / agent / admin
- **Cache** : Flask-Caching (5 min trajets, 2 min voyages)
- **Sécurité** : CSRF protection (Flask-WTF) sur tous les formulaires

---

## 📦 Dépendances principales

| Package           | Rôle                                  |
|-------------------|---------------------------------------|
| Flask             | Framework web                         |
| Flask-SQLAlchemy  | ORM base de données                   |
| Flask-Login       | Gestion des sessions utilisateur      |
| Flask-WTF         | Protection CSRF                       |
| Flask-Caching     | Mise en cache                         |
| Flask-Migrate     | Migrations de base de données         |
| qrcode + Pillow   | Génération de QR codes                |
| pytest            | Tests unitaires                       |
