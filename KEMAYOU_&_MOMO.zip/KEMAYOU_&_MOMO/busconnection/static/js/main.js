/**
 * BusConnect — main.js
 * Gestion UI : navbar mobile, alertes, sélecteur de classe,
 * confirmation, graphiques dashboard, compteurs animés.
 */

"use strict";

/* ──────────────────────────────────────────────────────────────
   1. Navbar mobile toggle
────────────────────────────────────────────────────────────── */
function initNavbar() {
  const toggler = document.querySelector(".navbar-toggler");
  const nav     = document.querySelector(".navbar-nav");
  if (!toggler || !nav) return;

  toggler.addEventListener("click", () => {
    nav.classList.toggle("open");
    toggler.setAttribute("aria-expanded", nav.classList.contains("open"));
  });

  // Fermer si clic hors du menu
  document.addEventListener("click", (e) => {
    if (!toggler.contains(e.target) && !nav.contains(e.target)) {
      nav.classList.remove("open");
    }
  });
}

/* ──────────────────────────────────────────────────────────────
   2. Auto-dismiss des alertes flash (4 secondes)
────────────────────────────────────────────────────────────── */
function initAlerts() {
  document.querySelectorAll(".alert").forEach((alert) => {
    // Bouton fermeture manuelle
    const closeBtn = alert.querySelector(".alert-close");
    if (closeBtn) {
      closeBtn.addEventListener("click", () => dismissAlert(alert));
    }

    // Auto-dismiss après 4s (sauf alertes danger)
    if (!alert.classList.contains("alert-danger")) {
      setTimeout(() => dismissAlert(alert), 4000);
    }
  });
}

function dismissAlert(alert) {
  alert.style.transition = "opacity 0.4s, max-height 0.4s, padding 0.4s, margin 0.4s";
  alert.style.opacity = "0";
  alert.style.maxHeight = "0";
  alert.style.padding = "0";
  alert.style.margin = "0";
  alert.style.overflow = "hidden";
  setTimeout(() => alert.remove(), 450);
}

/* ──────────────────────────────────────────────────────────────
   3. Sélecteur de classe (Classique / VIP)
────────────────────────────────────────────────────────────── */
function initClasseSelector() {
  const options = document.querySelectorAll(".classe-option");
  if (!options.length) return;

  options.forEach((opt) => {
    opt.addEventListener("click", () => {
      const radio = opt.querySelector("input[type='radio']");
      if (!radio) return;

      radio.checked = true;
      options.forEach((o) => o.classList.remove("selected-classique", "selected-vip"));

      if (radio.value === "VIP") {
        opt.classList.add("selected-vip");
      } else {
        opt.classList.add("selected-classique");
      }

      updatePriceDisplay(radio.value);
    });
  });

  // Sélectionner le premier par défaut
  const firstOpt = options[0];
  if (firstOpt) firstOpt.click();
}

function updatePriceDisplay(classe) {
  const priceEl = document.getElementById("prix-affiche");
  if (!priceEl) return;
  const prixClassique = priceEl.dataset.classique;
  const prixVip       = priceEl.dataset.vip;
  const fcfaEl        = document.getElementById("montant-confirm");

  if (classe === "VIP") {
    priceEl.textContent = `${parseInt(prixVip).toLocaleString("fr-FR")} FCFA`;
    if (fcfaEl) fcfaEl.textContent = `${parseInt(prixVip).toLocaleString("fr-FR")} FCFA`;
  } else {
    priceEl.textContent = `${parseInt(prixClassique).toLocaleString("fr-FR")} FCFA`;
    if (fcfaEl) fcfaEl.textContent = `${parseInt(prixClassique).toLocaleString("fr-FR")} FCFA`;
  }
}

/* ──────────────────────────────────────────────────────────────
   4. Confirmation avant action destructive
────────────────────────────────────────────────────────────── */
function initConfirmations() {
  document.querySelectorAll("[data-confirm]").forEach((el) => {
    el.addEventListener("click", (e) => {
      const msg = el.dataset.confirm || "Êtes-vous sûr de vouloir continuer ?";
      if (!confirm(msg)) {
        e.preventDefault();
        e.stopPropagation();
      }
    });
  });
}

/* ──────────────────────────────────────────────────────────────
   5. Graphiques du Dashboard (Chart.js)
────────────────────────────────────────────────────────────── */
function initDashboardCharts() {
  // Graphique recettes semaine (barres)
  const recettesCanvas = document.getElementById("chartRecettes");
  if (recettesCanvas && typeof Chart !== "undefined") {
    const labels = JSON.parse(recettesCanvas.dataset.labels || "[]");
    const values = JSON.parse(recettesCanvas.dataset.values || "[]");

    new Chart(recettesCanvas, {
      type: "bar",
      data: {
        labels,
        datasets: [{
          label: "Recettes (FCFA)",
          data: values,
          backgroundColor: "rgba(58, 180, 242, 0.75)",
          borderColor: "#3AB4F2",
          borderWidth: 2,
          borderRadius: 6,
        }],
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.raw.toLocaleString("fr-FR")} FCFA`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: (v) => v.toLocaleString("fr-FR"),
            },
          },
        },
      },
    });
  }

  // Graphique trajets populaires (doughnut)
  const trajetsCanvas = document.getElementById("chartTrajets");
  if (trajetsCanvas && typeof Chart !== "undefined") {
    const labels = JSON.parse(trajetsCanvas.dataset.labels || "[]");
    const values = JSON.parse(trajetsCanvas.dataset.values || "[]");

    new Chart(trajetsCanvas, {
      type: "doughnut",
      data: {
        labels,
        datasets: [{
          data: values,
          backgroundColor: [
            "#3AB4F2", "#E63946", "#1A1A1A", "#1E90D6", "#C1121F",
          ],
          borderWidth: 0,
        }],
      },
      options: {
        responsive: true,
        cutout: "65%",
        plugins: {
          legend: {
            position: "bottom",
            labels: { font: { size: 11 }, padding: 12 },
          },
        },
      },
    });
  }
}

/* ──────────────────────────────────────────────────────────────
   6. Compteurs animés (stat-card)
────────────────────────────────────────────────────────────── */
function initCounters() {
  document.querySelectorAll("[data-counter]").forEach((el) => {
    const target   = parseInt(el.dataset.counter, 10);
    const duration = 1200;
    const step     = target / (duration / 16);
    let current    = 0;

    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = Math.floor(current).toLocaleString("fr-FR");
      if (current >= target) clearInterval(timer);
    }, 16);
  });
}

/* ──────────────────────────────────────────────────────────────
   7. Filtrage tableau côté client
────────────────────────────────────────────────────────────── */
function initTableFilter() {
  const filterInput = document.getElementById("tableFilter");
  if (!filterInput) return;

  filterInput.addEventListener("input", () => {
    const q = filterInput.value.toLowerCase().trim();
    document.querySelectorAll("[data-filterable] tbody tr").forEach((row) => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? "" : "none";
    });
  });
}

/* ──────────────────────────────────────────────────────────────
   8. Impression du ticket
────────────────────────────────────────────────────────────── */
function initPrintTicket() {
  const btn = document.getElementById("btnPrint");
  if (btn) {
    btn.addEventListener("click", () => window.print());
  }
}

/* ──────────────────────────────────────────────────────────────
   9. Validation formulaire avant soumission
────────────────────────────────────────────────────────────── */
function initFormValidation() {
  document.querySelectorAll("form[data-validate]").forEach((form) => {
    form.addEventListener("submit", (e) => {
      let valid = true;
      form.querySelectorAll("[required]").forEach((field) => {
        if (!field.value.trim()) {
          field.classList.add("is-invalid");
          valid = false;
        } else {
          field.classList.remove("is-invalid");
        }
      });
      if (!valid) {
        e.preventDefault();
        showToast("Veuillez remplir tous les champs obligatoires.", "danger");
      }
    });
  });
}

/* ──────────────────────────────────────────────────────────────
   10. Toast notification légère
────────────────────────────────────────────────────────────── */
function showToast(message, type = "info") {
  const toast = document.createElement("div");
  toast.className = `alert alert-${type}`;
  toast.style.cssText = `
    position: fixed; bottom: 1.5rem; right: 1.5rem;
    z-index: 9999; max-width: 360px; box-shadow: 0 4px 16px rgba(0,0,0,0.18);
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => dismissAlert(toast), 3500);
}

window.showToast = showToast;

/* ──────────────────────────────────────────────────────────────
   Init globale au chargement du DOM
────────────────────────────────────────────────────────────── */
document.addEventListener("DOMContentLoaded", () => {
  initNavbar();
  initAlerts();
  initClasseSelector();
  initConfirmations();
  initDashboardCharts();
  initCounters();
  initTableFilter();
  initPrintTicket();
  initFormValidation();
});
