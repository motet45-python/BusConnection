from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db, login_manager



@login_manager.user_loader
def load_user(user_id):
    return Utilisateur.query.get(int(user_id))



class Utilisateur(UserMixin, db.Model):
    __tablename__ = "utilisateurs"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    telephone = db.Column(db.String(20))
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), default="client")  # client / agent / admin
    agence_id = db.Column(db.Integer, db.ForeignKey("agences.id"), nullable=True)
    date_inscription = db.Column(db.DateTime, default=datetime.utcnow)
    actif = db.Column(db.Boolean, default=True)

    reservations = db.relationship("Reservation", backref="passager", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        return self.role == "admin"

    def is_agent(self):
        return self.role == "agent"

    def __repr__(self):
        return f"<Utilisateur {self.email} [{self.role}]>"



class Agence(db.Model):
    __tablename__ = "agences"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    telephone = db.Column(db.String(20))
    adresse = db.Column(db.String(200))
    email = db.Column(db.String(120))
    actif = db.Column(db.Boolean, default=True)

    bus = db.relationship("Bus", backref="agence", lazy=True)
    utilisateurs = db.relationship("Utilisateur", backref="agence", lazy=True)

    def __repr__(self):
        return f"<Agence {self.nom}>"



class Bus(db.Model):
    __tablename__ = "bus"

    id = db.Column(db.Integer, primary_key=True)
    agence_id = db.Column(db.Integer, db.ForeignKey("agences.id"), nullable=False)
    numero_immatriculation = db.Column(db.String(20), unique=True, nullable=False)
    capacite = db.Column(db.Integer, nullable=False)
    type = db.Column(db.String(20), default="Classique")  # VIP / Classique
    actif = db.Column(db.Boolean, default=True)

    voyages = db.relationship("Voyage", backref="bus", lazy=True)

    def __repr__(self):
        return f"<Bus {self.numero_immatriculation} [{self.type}]>"



class Trajet(db.Model):
    __tablename__ = "trajets"

    id = db.Column(db.Integer, primary_key=True)
    ville_depart = db.Column(db.String(50), nullable=False)
    ville_arrivee = db.Column(db.String(50), nullable=False)
    duree_h = db.Column(db.Float, nullable=False)
    prix_classique_fcfa = db.Column(db.Integer, nullable=False)
    prix_vip_fcfa = db.Column(db.Integer, nullable=False)
    actif = db.Column(db.Boolean, default=True)

    voyages = db.relationship("Voyage", backref="trajet", lazy=True)

    def __repr__(self):
        return f"<Trajet {self.ville_depart} → {self.ville_arrivee}>"



class Voyage(db.Model):
    __tablename__ = "voyages"

    id = db.Column(db.Integer, primary_key=True)
    trajet_id = db.Column(db.Integer, db.ForeignKey("trajets.id"), nullable=False)
    bus_id = db.Column(db.Integer, db.ForeignKey("bus.id"), nullable=False)
    conducteur = db.Column(db.String(100))
    date_heure_depart = db.Column(db.DateTime, nullable=False)
    places_disponibles = db.Column(db.Integer, nullable=False)
    statut = db.Column(db.String(20), default="planifie")  # planifie / en_cours / termine / annule

    reservations = db.relationship("Reservation", backref="voyage", lazy=True)

    def taux_remplissage(self):
        if self.bus.capacite == 0:
            return 0
        reservees = self.bus.capacite - self.places_disponibles
        return round((reservees / self.bus.capacite) * 100, 1)

    def __repr__(self):
        return f"<Voyage {self.id} — {self.trajet} le {self.date_heure_depart}>"



class Reservation(db.Model):
    __tablename__ = "reservations"

    id = db.Column(db.Integer, primary_key=True)
    voyage_id = db.Column(db.Integer, db.ForeignKey("voyages.id"), nullable=False)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateurs.id"), nullable=True)
    passager_nom = db.Column(db.String(100), nullable=False)
    passager_telephone = db.Column(db.String(20), nullable=False)
    classe = db.Column(db.String(20), nullable=False)  # VIP / Classique
    numero_ticket = db.Column(db.String(20), unique=True, nullable=False)
    statut = db.Column(db.String(20), default="confirme")  # confirme / annule / en_attente
    date_reservation = db.Column(db.DateTime, default=datetime.utcnow)
    montant_fcfa = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"<Reservation {self.numero_ticket} — {self.passager_nom}>"


class ListeAttente(db.Model):
    __tablename__ = "liste_attente"

    id = db.Column(db.Integer, primary_key=True)
    voyage_id = db.Column(db.Integer, db.ForeignKey("voyages.id"), nullable=False)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateurs.id"), nullable=False)
    passager_nom = db.Column(db.String(100), nullable=False)
    passager_telephone = db.Column(db.String(20), nullable=False)
    classe = db.Column(db.String(20), nullable=False)
    date_inscription = db.Column(db.DateTime, default=datetime.utcnow)
    notifie = db.Column(db.Boolean, default=False)

    voyage = db.relationship("Voyage", backref="liste_attente")
    utilisateur = db.relationship("Utilisateur", backref="liste_attente")

    def __repr__(self):
        return f"<ListeAttente {self.passager_nom} — Voyage {self.voyage_id}>"
