"""
tests/test_reservations.py
Tests Pytest pour la gestion des réservations et annulations.
"""

import pytest
from datetime import datetime, timedelta
from app import create_app
from extensions import db
from models import Utilisateur, Agence, Bus, Trajet, Voyage, Reservation


@pytest.fixture
def app():
    """Crée une app Flask de test avec une base SQLite en mémoire."""
    app = create_app("development")
    app.config.update({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "WTF_CSRF_ENABLED": False,
        "SECRET_KEY": "test-secret",
    })

    with app.app_context():
        db.create_all()
        _inserer_donnees_test()
        yield app
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def app_context(app):
    with app.app_context():
        yield


# ─── Données de test ───────────────────────────────────────────────────────


def _inserer_donnees_test():
    """Insère des données minimales pour les tests."""
    agence = Agence(nom="Test Express", telephone="699000000",
                    adresse="Douala Test", email="test@express.cm")
    db.session.add(agence)
    db.session.flush()

    bus = Bus(agence_id=agence.id, numero_immatriculation="TEST-001",
              capacite=10, type="Classique")
    db.session.add(bus)
    db.session.flush()

    trajet = Trajet(ville_depart="Douala", ville_arrivee="Yaoundé",
                    duree_h=3.5, prix_classique_fcfa=3000, prix_vip_fcfa=6000)
    db.session.add(trajet)
    db.session.flush()

    voyage = Voyage(
        trajet_id=trajet.id,
        bus_id=bus.id,
        conducteur="Test Driver",
        date_heure_depart=datetime.utcnow() + timedelta(days=3),
        places_disponibles=10,
        statut="planifie",
    )
    db.session.add(voyage)

    user = Utilisateur(nom="Test User", email="user@test.cm",
                       telephone="677000000", role="client")
    user.set_password("test123")
    db.session.add(user)

    db.session.commit()


# ─── Tests ─────────────────────────────────────────────────────────────────


class TestDisponibilite:
    """Tests de la gestion des places disponibles."""

    def test_voyage_initial_a_places(self, app_context):
        from models import Voyage
        voyage = Voyage.query.first()
        assert voyage.places_disponibles == 10

    def test_verifier_disponibilite_ok(self, app_context):
        from functions.disponibilite import verifier_disponibilite
        voyage = Voyage.query.first()
        assert verifier_disponibilite(voyage.id) is True

    def test_reserver_place_decremente(self, app_context):
        from functions.disponibilite import reserver_place
        voyage = Voyage.query.first()
        voyage_id = voyage.id
        succes = reserver_place(voyage_id)
        assert succes is True
        voyage_maj = Voyage.query.get(voyage_id)
        assert voyage_maj.places_disponibles == 9

    def test_liberer_place_incremente(self, app_context):
        from functions.disponibilite import reserver_place, liberer_place
        voyage = Voyage.query.first()
        reserver_place(voyage.id)
        liberer_place(voyage.id)
        voyage_maj = Voyage.query.get(voyage.id)
        assert voyage_maj.places_disponibles == 10

    def test_pas_de_surreservation(self, app_context):
        from functions.disponibilite import reserver_place
        voyage = Voyage.query.first()
        for _ in range(10):
            reserver_place(voyage.id)
        # La 11e tentative doit échouer
        succes = reserver_place(voyage.id)
        assert succes is False


class TestTicket:
    """Tests de la génération de tickets."""

    def test_numero_ticket_unique(self, app_context):
        from functions.ticket import generer_numero_ticket
        numeros = {generer_numero_ticket() for _ in range(50)}
        assert len(numeros) == 50

    def test_format_numero_ticket(self, app_context):
        from functions.ticket import generer_numero_ticket
        numero = generer_numero_ticket()
        assert numero.startswith("BC-")
        parts = numero.split("-")
        assert len(parts) == 3
        assert len(parts[1]) == 8   # YYYYMMDD
        assert len(parts[2]) == 4   # 4 hex

    def test_qr_code_base64(self, app_context):
        from functions.ticket import generer_qr_code_base64
        b64 = generer_qr_code_base64("TEST:12345")
        assert b64.startswith("data:image/png;base64,")


class TestAnnulation:
    """Tests de la politique d'annulation et remboursement."""

    def _creer_reservation(self, voyage_id, montant=3000):
        from functions.ticket import generer_numero_ticket
        user = Utilisateur.query.first()
        r = Reservation(
            voyage_id=voyage_id,
            utilisateur_id=user.id,
            passager_nom="Test Passager",
            passager_telephone="677000001",
            classe="Classique",
            numero_ticket=generer_numero_ticket(),
            statut="confirme",
            montant_fcfa=montant,
        )
        db.session.add(r)
        db.session.commit()
        return r

    def test_remboursement_plus_48h(self, app_context):
        from functions.annulation import calculer_remboursement
        voyage = Voyage.query.first()
        voyage.date_heure_depart = datetime.utcnow() + timedelta(days=5)
        db.session.commit()

        r = self._creer_reservation(voyage.id)
        info = calculer_remboursement(r)
        assert info["pourcentage"] == 100

    def test_remboursement_entre_24h_48h(self, app_context):
        from functions.annulation import calculer_remboursement
        voyage = Voyage.query.first()
        voyage.date_heure_depart = datetime.utcnow() + timedelta(hours=36)
        db.session.commit()

        r = self._creer_reservation(voyage.id)
        info = calculer_remboursement(r)
        assert info["pourcentage"] == 50

    def test_remboursement_moins_24h(self, app_context):
        from functions.annulation import calculer_remboursement
        voyage = Voyage.query.first()
        voyage.date_heure_depart = datetime.utcnow() + timedelta(hours=10)
        db.session.commit()

        r = self._creer_reservation(voyage.id)
        info = calculer_remboursement(r)
        assert info["pourcentage"] == 0

    def test_annuler_reservation(self, app_context):
        from functions.annulation import annuler_reservation
        voyage = Voyage.query.first()
        voyage.date_heure_depart = datetime.utcnow() + timedelta(days=5)
        db.session.commit()

        r = self._creer_reservation(voyage.id)
        places_avant = voyage.places_disponibles

        succes, msg, info = annuler_reservation(r.id)
        assert succes is True

        r_maj = Reservation.query.get(r.id)
        assert r_maj.statut == "annule"

        voyage_maj = Voyage.query.get(voyage.id)
        assert voyage_maj.places_disponibles == places_avant + 1

    def test_double_annulation_impossible(self, app_context):
        from functions.annulation import annuler_reservation
        voyage = Voyage.query.first()
        r = self._creer_reservation(voyage.id)
        annuler_reservation(r.id)
        succes, msg, _ = annuler_reservation(r.id)
        assert succes is False


class TestRechercheTrajets:
    """Tests de l'algorithme BFS de recherche de trajets."""

    def test_trajet_direct_trouve(self, app_context):
        from functions.recherche_trajet import rechercher_itineraires
        resultats = rechercher_itineraires("Douala", "Yaoundé")
        assert len(resultats) > 0
        assert resultats[0]["villes"][0] == "Douala"
        assert resultats[0]["villes"][-1] == "Yaoundé"

    def test_trajet_inexistant_retourne_vide(self, app_context):
        from functions.recherche_trajet import rechercher_itineraires
        resultats = rechercher_itineraires("Paris", "Tokyo")
        assert resultats == []
