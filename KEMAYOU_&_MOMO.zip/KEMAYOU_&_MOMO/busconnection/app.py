"""
app.py
Point d'entrée de l'application BusConnect.
Chaque fonctionnalité est dans son propre module (routes/ et functions/).
"""

import os
from flask import Flask
from config import config
from extensions import db, login_manager, migrate, cache, csrf


from routes.main import main_bp
from routes.auth import auth_bp
from routes.agences import agences_bp
from routes.bus import bus_bp
from routes.trajets import trajets_bp
from routes.voyages import voyages_bp
from routes.reservations import reservations_bp
from routes.dashboard import dashboard_bp


def create_app(config_name: str = "default") -> Flask:
    """Factory function — crée et configure l'application Flask."""

    app = Flask(__name__)
    app.config.from_object(config[config_name])


    os.makedirs(app.config.get("TICKET_FOLDER", "static/tickets"), exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    cache.init_app(app)
    csrf.init_app(app)


    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(agences_bp)
    app.register_blueprint(bus_bp)
    app.register_blueprint(trajets_bp)
    app.register_blueprint(voyages_bp)
    app.register_blueprint(reservations_bp)
    app.register_blueprint(dashboard_bp)


    with app.app_context():
        db.create_all()
        _seed_data()

    return app


def _seed_data():
    """Insère les données de test si la base est vide."""
    from models import Agence, Bus, Trajet, Voyage, Utilisateur
    from datetime import datetime, timedelta

    if Agence.query.first():
        return  # Déjà initialisé


    admin = Utilisateur(nom="Admin BusConnect", email="admin@busconnect.cm",
                        telephone="699000001", role="admin")
    admin.set_password("admin123")

    agent = Utilisateur(nom="Agent Général", email="agent@busconnect.cm",
                        telephone="699000002", role="agent")
    agent.set_password("agent123")

    client = Utilisateur(nom="Jean Fotso", email="jean@example.cm",
                         telephone="677001122", role="client")
    client.set_password("client123")

    db.session.add_all([admin, agent, client])
    db.session.flush()


    agences_data = [
        {"nom": "Général Express", "telephone": "233421001",
         "adresse": "Gare routière de Douala", "email": "info@generalexpress.cm"},
        {"nom": "Vatican Express", "telephone": "233422002",
         "adresse": "Gare routière de Yaoundé", "email": "contact@vaticanexpress.cm"},
        {"nom": "Buca Voyages", "telephone": "233423003",
         "adresse": "Bafoussam Centre", "email": "buca@voyages.cm"},
    ]
    agences = []
    for d in agences_data:
        a = Agence(**d)
        db.session.add(a)
        agences.append(a)
    db.session.flush()


    agent.agence_id = agences[0].id


    bus_data = [
        {"agence_id": agences[0].id, "numero_immatriculation": "LT-001-SW",
         "capacite": 70, "type": "Classique"},
        {"agence_id": agences[0].id, "numero_immatriculation": "LT-002-SW",
         "capacite": 30, "type": "VIP"},
        {"agence_id": agences[1].id, "numero_immatriculation": "CE-101-YD",
         "capacite": 70, "type": "Classique"},
        {"agence_id": agences[2].id, "numero_immatriculation": "OU-201-BF",
         "capacite": 50, "type": "Classique"},
    ]
    bus_list = []
    for d in bus_data:
        b = Bus(**d)
        db.session.add(b)
        bus_list.append(b)
    db.session.flush()


    trajets_data = [
        {"ville_depart": "Douala", "ville_arrivee": "Yaoundé",
         "duree_h": 3.5, "prix_classique_fcfa": 3000, "prix_vip_fcfa": 6000},
        {"ville_depart": "Yaoundé", "ville_arrivee": "Douala",
         "duree_h": 3.5, "prix_classique_fcfa": 3000, "prix_vip_fcfa": 6000},
        {"ville_depart": "Douala", "ville_arrivee": "Bafoussam",
         "duree_h": 4.0, "prix_classique_fcfa": 3500, "prix_vip_fcfa": 7000},
        {"ville_depart": "Yaoundé", "ville_arrivee": "Ngaoundéré",
         "duree_h": 8.0, "prix_classique_fcfa": 6000, "prix_vip_fcfa": 12000},
        {"ville_depart": "Ngaoundéré", "ville_arrivee": "Maroua",
         "duree_h": 6.0, "prix_classique_fcfa": 5000, "prix_vip_fcfa": 10000},
        {"ville_depart": "Bafoussam", "ville_arrivee": "Yaoundé",
         "duree_h": 4.5, "prix_classique_fcfa": 3500, "prix_vip_fcfa": 7000},
    ]
    trajets = []
    for d in trajets_data:
        t = Trajet(**d)
        db.session.add(t)
        trajets.append(t)
    db.session.flush()


    now = datetime.utcnow()
    voyages_data = [
        {"trajet_id": trajets[0].id, "bus_id": bus_list[0].id,
         "conducteur": "Paul Mbarga", "date_heure_depart": now + timedelta(hours=2),
         "places_disponibles": 70},
        {"trajet_id": trajets[0].id, "bus_id": bus_list[1].id,
         "conducteur": "Henri Nkodo", "date_heure_depart": now + timedelta(hours=6),
         "places_disponibles": 30},
        {"trajet_id": trajets[1].id, "bus_id": bus_list[2].id,
         "conducteur": "Samuel Talla", "date_heure_depart": now + timedelta(hours=4),
         "places_disponibles": 70},
        {"trajet_id": trajets[2].id, "bus_id": bus_list[3].id,
         "conducteur": "Robert Biya", "date_heure_depart": now + timedelta(days=1),
         "places_disponibles": 50},
        {"trajet_id": trajets[3].id, "bus_id": bus_list[2].id,
         "conducteur": "Jacques Ateba", "date_heure_depart": now + timedelta(days=1, hours=8),
         "places_disponibles": 70},
        {"trajet_id": trajets[4].id, "bus_id": bus_list[0].id,
         "conducteur": "Denis Meyong", "date_heure_depart": now + timedelta(days=2),
         "places_disponibles": 70},
    ]
    for d in voyages_data:
        v = Voyage(**d, statut="planifie")
        db.session.add(v)

    db.session.commit()
    print(" Données de test insérées avec succès.")


if __name__ == "__main__":
    app = create_app("development")
    app.run(debug=True, host="0.0.0.0", port=5000)
