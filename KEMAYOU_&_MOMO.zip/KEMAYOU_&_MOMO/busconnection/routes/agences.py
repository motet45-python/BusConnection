

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from extensions import db
from models import Agence

agences_bp = Blueprint("agences", __name__, url_prefix="/agences")


def admin_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not current_user.is_admin():
            flash("Accès réservé aux administrateurs.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return decorated


@agences_bp.route("/")
@login_required
def liste():
    agences = Agence.query.order_by(Agence.nom).all()
    return render_template("agences/liste.html", agences=agences)


@agences_bp.route("/nouvelle", methods=["GET", "POST"])
@admin_required
def nouvelle():
    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        telephone = request.form.get("telephone", "").strip()
        adresse = request.form.get("adresse", "").strip()
        email = request.form.get("email", "").strip()

        if not nom:
            flash("Le nom de l'agence est obligatoire.", "warning")
        else:
            agence = Agence(nom=nom, telephone=telephone, adresse=adresse, email=email)
            db.session.add(agence)
            db.session.commit()
            flash("Agence créée avec succès.", "success")
            return redirect(url_for("agences.liste"))

    return render_template("agences/form.html", agence=None)


@agences_bp.route("/modifier/<int:agence_id>", methods=["GET", "POST"])
@admin_required
def modifier(agence_id):
    agence = Agence.query.get_or_404(agence_id)

    if request.method == "POST":
        agence.nom = request.form.get("nom", "").strip()
        agence.telephone = request.form.get("telephone", "").strip()
        agence.adresse = request.form.get("adresse", "").strip()
        agence.email = request.form.get("email", "").strip()
        db.session.commit()
        flash("Agence mise à jour.", "success")
        return redirect(url_for("agences.liste"))

    return render_template("agences/form.html", agence=agence)


@agences_bp.route("/supprimer/<int:agence_id>", methods=["POST"])
@admin_required
def supprimer(agence_id):
    agence = Agence.query.get_or_404(agence_id)
    agence.actif = False
    db.session.commit()
    flash("Agence désactivée.", "info")
    return redirect(url_for("agences.liste"))
