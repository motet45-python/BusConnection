
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from extensions import db
from models import Voyage, Reservation, Trajet
from functions.disponibilite import verifier_disponibilite, reserver_place
from functions.ticket import generer_numero_ticket, get_ticket_data
from functions.annulation import annuler_reservation, calculer_remboursement
from functions.cache_utils import invalider_cache_voyage

reservations_bp = Blueprint("reservations", __name__, url_prefix="/reservations")


@reservations_bp.route("/nouvelle/<int:voyage_id>", methods=["GET", "POST"])
def nouvelle(voyage_id):
    voyage = Voyage.query.get_or_404(voyage_id)

    if not verifier_disponibilite(voyage_id):
        flash("Plus de places disponibles pour ce voyage.", "warning")
        return redirect(url_for("main.index"))

    if request.method == "POST":
        passager_nom = request.form.get("passager_nom", "").strip()
        passager_telephone = request.form.get("passager_telephone", "").strip()
        classe = request.form.get("classe", "Classique")

        if not passager_nom or not passager_telephone:
            flash("Nom et téléphone sont obligatoires.", "danger")
            return render_template("reservations/formulaire.html", voyage=voyage)

        if classe == "VIP":
            montant = voyage.trajet.prix_vip_fcfa
        else:
            montant = voyage.trajet.prix_classique_fcfa
            classe = "Classique"

        # Verrou atomique sur les places
        if not reserver_place(voyage_id):
            flash("Désolé, la dernière place vient d'être prise. Veuillez réessayer.", "warning")
            return redirect(url_for("main.index"))

        reservation = Reservation(
            voyage_id=voyage_id,
            utilisateur_id=current_user.id if current_user.is_authenticated else None,
            passager_nom=passager_nom,
            passager_telephone=passager_telephone,
            classe=classe,
            numero_ticket=generer_numero_ticket(),
            statut="confirme",
            montant_fcfa=montant,
        )
        db.session.add(reservation)
        db.session.commit()

        invalider_cache_voyage(voyage.trajet.ville_depart, voyage.trajet.ville_arrivee)

        flash("Réservation confirmée !", "success")
        return redirect(url_for("reservations.ticket", reservation_id=reservation.id))

    return render_template("reservations/formulaire.html", voyage=voyage)


@reservations_bp.route("/ticket/<int:reservation_id>")
def ticket(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    ticket_data = get_ticket_data(reservation)
    return render_template("reservations/ticket.html", ticket=ticket_data, reservation=reservation)


@reservations_bp.route("/annuler/<int:reservation_id>", methods=["GET", "POST"])
@login_required
def annuler(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)

    # Sécurité : seul le passager ou un admin/agent peut annuler
    if (reservation.utilisateur_id != current_user.id
            and not current_user.is_admin()
            and not current_user.is_agent()):
        abort(403)

    info_remboursement = calculer_remboursement(reservation)

    if request.method == "POST":
        succes, message, info = annuler_reservation(reservation_id)
        if succes:
            flash(f"Réservation annulée. {message}", "info")
        else:
            flash(message, "danger")
        return redirect(url_for("reservations.mes_reservations"))

    return render_template(
        "reservations/annulation.html",
        reservation=reservation,
        info_remboursement=info_remboursement,
    )


@reservations_bp.route("/mes-reservations")
@login_required
def mes_reservations():
    reservations = (
        Reservation.query
        .filter_by(utilisateur_id=current_user.id)
        .order_by(Reservation.date_reservation.desc())
        .all()
    )
    return render_template("reservations/liste.html", reservations=reservations)
