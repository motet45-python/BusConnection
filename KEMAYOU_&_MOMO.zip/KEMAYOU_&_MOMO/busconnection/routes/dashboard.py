
from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from functools import wraps
from functions.dashboard import (
    get_stats_globales,
    get_taux_remplissage_par_voyage,
    get_trajets_populaires,
    get_recettes_semaine,
)
import json

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="/dashboard")


def agent_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not (current_user.is_admin() or current_user.is_agent()):
            flash("Accès réservé aux agents et administrateurs.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return decorated


@dashboard_bp.route("/")
@agent_required
def index():
    agence_id = current_user.agence_id

    if not agence_id and not current_user.is_admin():
        flash("Aucune agence associée à votre compte.", "warning")
        return redirect(url_for("main.index"))

    # Pour l'admin, on prend la première agence disponible
    if current_user.is_admin() and not agence_id:
        from models import Agence
        agence = Agence.query.filter_by(actif=True).first()
        agence_id = agence.id if agence else None

    stats = get_stats_globales(agence_id)
    taux_remplissage = get_taux_remplissage_par_voyage(agence_id)
    trajets_pop = get_trajets_populaires(agence_id)
    recettes_semaine = get_recettes_semaine(agence_id)

    # Données JSON pour les graphiques JS
    labels_semaine = json.dumps([r["jour"] for r in recettes_semaine])
    data_semaine = json.dumps([r["recettes"] for r in recettes_semaine])
    labels_trajets = json.dumps([t["trajet"] for t in trajets_pop])
    data_trajets = json.dumps([t["nb_reservations"] for t in trajets_pop])

    return render_template(
        "dashboard/agence.html",
        stats=stats,
        taux_remplissage=taux_remplissage,
        trajets_populaires=trajets_pop,
        recettes_semaine=recettes_semaine,
        labels_semaine=labels_semaine,
        data_semaine=data_semaine,
        labels_trajets=labels_trajets,
        data_trajets=data_trajets,
    )
