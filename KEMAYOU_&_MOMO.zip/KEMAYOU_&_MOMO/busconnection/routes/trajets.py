
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from extensions import db, cache
from models import Trajet

trajets_bp = Blueprint("trajets", __name__, url_prefix="/trajets")


def agent_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not (current_user.is_admin() or current_user.is_agent()):
            flash("Accès réservé aux agents et administrateurs.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return decorated


@trajets_bp.route("/")
@agent_required
def liste():
    trajets = Trajet.query.filter_by(actif=True).order_by(Trajet.ville_depart).all()
    return render_template("trajets/liste.html", trajets=trajets)


@trajets_bp.route("/nouveau", methods=["GET", "POST"])
@agent_required
def nouveau():
    if request.method == "POST":
        ville_depart = request.form.get("ville_depart", "").strip().title()
        ville_arrivee = request.form.get("ville_arrivee", "").strip().title()
        duree_h = request.form.get("duree_h", type=float)
        prix_classique = request.form.get("prix_classique_fcfa", type=int)
        prix_vip = request.form.get("prix_vip_fcfa", type=int)

        if not all([ville_depart, ville_arrivee, duree_h, prix_classique, prix_vip]):
            flash("Tous les champs sont obligatoires.", "warning")
        elif ville_depart == ville_arrivee:
            flash("La ville de départ et d'arrivée doivent être différentes.", "danger")
        else:
            trajet = Trajet(
                ville_depart=ville_depart,
                ville_arrivee=ville_arrivee,
                duree_h=duree_h,
                prix_classique_fcfa=prix_classique,
                prix_vip_fcfa=prix_vip,
            )
            db.session.add(trajet)
            db.session.commit()
            cache.delete("trajets_actifs")
            flash("Trajet créé avec succès.", "success")
            return redirect(url_for("trajets.liste"))

    return render_template("trajets/form.html", trajet=None)


@trajets_bp.route("/modifier/<int:trajet_id>", methods=["GET", "POST"])
@agent_required
def modifier(trajet_id):
    trajet = Trajet.query.get_or_404(trajet_id)

    if request.method == "POST":
        trajet.ville_depart = request.form.get("ville_depart", "").strip().title()
        trajet.ville_arrivee = request.form.get("ville_arrivee", "").strip().title()
        trajet.duree_h = request.form.get("duree_h", type=float)
        trajet.prix_classique_fcfa = request.form.get("prix_classique_fcfa", type=int)
        trajet.prix_vip_fcfa = request.form.get("prix_vip_fcfa", type=int)
        db.session.commit()
        cache.delete("trajets_actifs")
        flash("Trajet mis à jour.", "success")
        return redirect(url_for("trajets.liste"))

    return render_template("trajets/form.html", trajet=trajet)


@trajets_bp.route("/supprimer/<int:trajet_id>", methods=["POST"])
@agent_required
def supprimer(trajet_id):
    trajet = Trajet.query.get_or_404(trajet_id)
    trajet.actif = False
    db.session.commit()
    cache.delete("trajets_actifs")
    flash("Trajet désactivé.", "info")
    return redirect(url_for("trajets.liste"))
