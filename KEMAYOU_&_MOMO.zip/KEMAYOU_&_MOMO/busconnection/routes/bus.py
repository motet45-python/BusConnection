

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from extensions import db
from models import Bus, Agence

bus_bp = Blueprint("bus", __name__, url_prefix="/bus")


def agent_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not (current_user.is_admin() or current_user.is_agent()):
            flash("Accès réservé aux agents et administrateurs.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return decorated


@bus_bp.route("/")
@agent_required
def liste():
    bus_list = Bus.query.filter_by(actif=True).order_by(Bus.numero_immatriculation).all()
    return render_template("bus/liste.html", bus_list=bus_list)


@bus_bp.route("/nouveau", methods=["GET", "POST"])
@agent_required
def nouveau():
    agences = Agence.query.filter_by(actif=True).all()

    if request.method == "POST":
        agence_id = request.form.get("agence_id", type=int)
        numero = request.form.get("numero_immatriculation", "").strip().upper()
        capacite = request.form.get("capacite", type=int)
        type_bus = request.form.get("type", "Classique")

        if not all([agence_id, numero, capacite]):
            flash("Tous les champs sont obligatoires.", "warning")
        elif Bus.query.filter_by(numero_immatriculation=numero).first():
            flash("Ce numéro d'immatriculation existe déjà.", "danger")
        else:
            bus = Bus(agence_id=agence_id, numero_immatriculation=numero,
                      capacite=capacite, type=type_bus)
            db.session.add(bus)
            db.session.commit()
            flash("Bus ajouté avec succès.", "success")
            return redirect(url_for("bus.liste"))

    return render_template("bus/form.html", agences=agences, bus=None)


@bus_bp.route("/modifier/<int:bus_id>", methods=["GET", "POST"])
@agent_required
def modifier(bus_id):
    bus = Bus.query.get_or_404(bus_id)
    agences = Agence.query.filter_by(actif=True).all()

    if request.method == "POST":
        bus.agence_id = request.form.get("agence_id", type=int)
        bus.numero_immatriculation = request.form.get("numero_immatriculation", "").strip().upper()
        bus.capacite = request.form.get("capacite", type=int)
        bus.type = request.form.get("type", "Classique")
        db.session.commit()
        flash("Bus mis à jour.", "success")
        return redirect(url_for("bus.liste"))

    return render_template("bus/form.html", agences=agences, bus=bus)


@bus_bp.route("/supprimer/<int:bus_id>", methods=["POST"])
@agent_required
def supprimer(bus_id):
    bus = Bus.query.get_or_404(bus_id)
    bus.actif = False
    db.session.commit()
    flash("Bus désactivé.", "info")
    return redirect(url_for("bus.liste"))
