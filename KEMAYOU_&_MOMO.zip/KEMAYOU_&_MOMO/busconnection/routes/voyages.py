

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from functools import wraps
from extensions import db
from models import Voyage, Trajet, Bus
from datetime import datetime

voyages_bp = Blueprint("voyages", __name__, url_prefix="/voyages")


def agent_required(f):
    @wraps(f)
    @login_required
    def decorated(*args, **kwargs):
        if not (current_user.is_admin() or current_user.is_agent()):
            flash("Accès réservé aux agents et administrateurs.", "danger")
            return redirect(url_for("main.index"))
        return f(*args, **kwargs)
    return decorated


@voyages_bp.route("/")
@agent_required
def liste():
    voyages = Voyage.query.order_by(Voyage.date_heure_depart.desc()).all()
    return render_template("voyages/liste.html", voyages=voyages)


@voyages_bp.route("/nouveau", methods=["GET", "POST"])
@agent_required
def nouveau():
    trajets = Trajet.query.filter_by(actif=True).all()
    bus_list = Bus.query.filter_by(actif=True).all()

    if request.method == "POST":
        trajet_id = request.form.get("trajet_id", type=int)
        bus_id = request.form.get("bus_id", type=int)
        conducteur = request.form.get("conducteur", "").strip()
        date_heure_str = request.form.get("date_heure_depart", "")

        try:
            date_heure = datetime.strptime(date_heure_str, "%Y-%m-%dT%H:%M")
        except ValueError:
            flash("Format de date invalide.", "danger")
            return render_template("voyages/form.html", trajets=trajets, bus_list=bus_list)

        bus = Bus.query.get(bus_id)
        if not bus:
            flash("Bus introuvable.", "danger")
            return render_template("voyages/form.html", trajets=trajets, bus_list=bus_list)

        voyage = Voyage(
            trajet_id=trajet_id,
            bus_id=bus_id,
            conducteur=conducteur,
            date_heure_depart=date_heure,
            places_disponibles=bus.capacite,
            statut="planifie",
        )
        db.session.add(voyage)
        db.session.commit()
        flash("Voyage créé avec succès.", "success")
        return redirect(url_for("voyages.liste"))

    return render_template("voyages/form.html", trajets=trajets, bus_list=bus_list, voyage=None)


@voyages_bp.route("/modifier/<int:voyage_id>", methods=["GET", "POST"])
@agent_required
def modifier(voyage_id):
    voyage = Voyage.query.get_or_404(voyage_id)
    trajets = Trajet.query.filter_by(actif=True).all()
    bus_list = Bus.query.filter_by(actif=True).all()

    if request.method == "POST":
        voyage.trajet_id = request.form.get("trajet_id", type=int)
        voyage.bus_id = request.form.get("bus_id", type=int)
        voyage.conducteur = request.form.get("conducteur", "").strip()
        voyage.statut = request.form.get("statut", voyage.statut)
        date_heure_str = request.form.get("date_heure_depart", "")
        try:
            voyage.date_heure_depart = datetime.strptime(date_heure_str, "%Y-%m-%dT%H:%M")
        except ValueError:
            flash("Format de date invalide.", "danger")

        db.session.commit()
        flash("Voyage mis à jour.", "success")
        return redirect(url_for("voyages.liste"))

    return render_template("voyages/form.html", trajets=trajets, bus_list=bus_list, voyage=voyage)


@voyages_bp.route("/supprimer/<int:voyage_id>", methods=["POST"])
@agent_required
def supprimer(voyage_id):
    voyage = Voyage.query.get_or_404(voyage_id)
    voyage.statut = "annule"
    db.session.commit()
    flash("Voyage annulé.", "info")
    return redirect(url_for("voyages.liste"))
