

from flask import Blueprint, render_template, request
from datetime import datetime
from functions.recherche_trajet import rechercher_itineraires, get_villes_disponibles
from functions.cache_utils import get_voyages_disponibles_caches

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    villes = get_villes_disponibles()
    return render_template("index.html", villes=villes)


@main_bp.route("/recherche")
def recherche():
    depart = request.args.get("depart", "").strip()
    arrivee = request.args.get("arrivee", "").strip()
    date_str = request.args.get("date_voyage", "")
    villes = get_villes_disponibles()

    voyages = []
    itineraires = []
    date_voyage = None

    if depart and arrivee:
        if date_str:
            try:
                date_voyage = datetime.strptime(date_str, "%Y-%m-%d").date()
            except ValueError:
                date_voyage = None

        # Voyages directs depuis le cache
        voyages = get_voyages_disponibles_caches(depart, arrivee, date_voyage)

        # Trajets avec correspondances (BFS) si aucun voyage direct
        if not voyages:
            itineraires = rechercher_itineraires(depart, arrivee)

    return render_template(
        "trajets/recherche.html",
        villes=villes,
        depart=depart,
        arrivee=arrivee,
        date_voyage=date_str,
        voyages=voyages,
        itineraires=itineraires,
    )
