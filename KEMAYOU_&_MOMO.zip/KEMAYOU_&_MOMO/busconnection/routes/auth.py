

from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db
from models import Utilisateur

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember") == "on"

        user = Utilisateur.query.filter_by(email=email).first()
        if user and user.check_password(password) and user.actif:
            login_user(user, remember=remember)
            flash(f"Bienvenue, {user.nom} !", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("main.index"))
        else:
            flash("Email ou mot de passe incorrect.", "danger")

    return render_template("auth/login.html")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))

    if request.method == "POST":
        nom = request.form.get("nom", "").strip()
        email = request.form.get("email", "").strip().lower()
        telephone = request.form.get("telephone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not all([nom, email, password]):
            flash("Tous les champs obligatoires doivent être remplis.", "warning")
        elif password != confirm:
            flash("Les mots de passe ne correspondent pas.", "danger")
        elif Utilisateur.query.filter_by(email=email).first():
            flash("Un compte avec cet email existe déjà.", "danger")
        else:
            user = Utilisateur(nom=nom, email=email, telephone=telephone, role="client")
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("Compte créé avec succès. Bienvenue !", "success")
            return redirect(url_for("main.index"))

    return render_template("auth/register.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Vous avez été déconnecté.", "info")
    return redirect(url_for("main.index"))
