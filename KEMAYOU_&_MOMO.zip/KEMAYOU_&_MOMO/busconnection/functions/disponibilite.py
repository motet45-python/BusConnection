"""
disponibilite.py
Gestion de la disponibilité des places et prévention de la surréservation.
"""

from extensions import db
from models import Voyage, Reservation


def verifier_disponibilite(voyage_id: int, nombre_places: int = 1) -> bool:
    """
    Vérifie si un voyage dispose du nombre de places demandées.
    Retourne True si disponible, False sinon.
    """
    voyage = Voyage.query.with_for_update().get(voyage_id)
    if not voyage:
        return False
    return voyage.places_disponibles >= nombre_places


def reserver_place(voyage_id: int, nombre_places: int = 1) -> bool:
    """
    Décrémente les places disponibles d'un voyage de façon atomique.
    Utilise un verrou (with_for_update) pour éviter la surréservation.
    Retourne True si la réservation est possible et effectuée, False sinon.
    """
    voyage = Voyage.query.with_for_update().get(voyage_id)
    if not voyage:
        return False
    if voyage.places_disponibles < nombre_places:
        return False
    voyage.places_disponibles -= nombre_places
    db.session.commit()
    return True


def liberer_place(voyage_id: int, nombre_places: int = 1) -> bool:
    """
    Incrémente les places disponibles lors d'une annulation.
    Retourne True si succès, False sinon.
    """
    voyage = Voyage.query.with_for_update().get(voyage_id)
    if not voyage:
        return False
    voyage.places_disponibles += nombre_places
    db.session.commit()
    return True


def get_places_restantes(voyage_id: int) -> int:
    """
    Retourne le nombre de places encore disponibles pour un voyage.
    """
    voyage = Voyage.query.get(voyage_id)
    if not voyage:
        return 0
    return voyage.places_disponibles


def get_taux_remplissage(voyage_id: int) -> float:
    """
    Calcule le taux de remplissage (en %) d'un voyage.
    """
    voyage = Voyage.query.get(voyage_id)
    if not voyage or voyage.bus.capacite == 0:
        return 0.0
    reservees = voyage.bus.capacite - voyage.places_disponibles
    return round((reservees / voyage.bus.capacite) * 100, 1)
