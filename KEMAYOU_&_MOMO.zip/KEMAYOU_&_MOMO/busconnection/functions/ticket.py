"""
ticket.py
Génération du ticket de réservation numérique (numéro unique + QR code).
"""

import os
import uuid
import qrcode
from io import BytesIO
import base64
from datetime import datetime


def generer_numero_ticket() -> str:
    """
    Génère un numéro de ticket unique au format BC-YYYYMMDD-XXXX.
    Ex : BC-20250612-A3F7
    """
    date_str = datetime.utcnow().strftime("%Y%m%d")
    code_unique = uuid.uuid4().hex[:4].upper()
    return f"BC-{date_str}-{code_unique}"


def generer_qr_code_base64(data: str) -> str:
    """
    Génère un QR code à partir d'une chaîne de caractères
    et retourne l'image encodée en base64 (pour l'afficher dans un <img> HTML).
    """
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=6,
        border=2,
    )
    qr.add_data(data)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer, format="PNG")
    buffer.seek(0)
    img_b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{img_b64}"


def get_ticket_data(reservation) -> dict:
    """
    Construit le dictionnaire de données d'un ticket à partir d'un objet Reservation.
    Utilisé pour le rendu HTML et la génération PDF.
    """
    voyage = reservation.voyage
    trajet = voyage.trajet

    qr_data = (
        f"TICKET:{reservation.numero_ticket}\n"
        f"PASSAGER:{reservation.passager_nom}\n"
        f"TRAJET:{trajet.ville_depart}→{trajet.ville_arrivee}\n"
        f"DEPART:{voyage.date_heure_depart.strftime('%d/%m/%Y %H:%M')}\n"
        f"CLASSE:{reservation.classe}\n"
        f"MONTANT:{reservation.montant_fcfa} FCFA"
    )

    return {
        "numero_ticket": reservation.numero_ticket,
        "passager_nom": reservation.passager_nom,
        "passager_telephone": reservation.passager_telephone,
        "ville_depart": trajet.ville_depart,
        "ville_arrivee": trajet.ville_arrivee,
        "date_depart": voyage.date_heure_depart.strftime("%d/%m/%Y"),
        "heure_depart": voyage.date_heure_depart.strftime("%H:%M"),
        "duree_h": trajet.duree_h,
        "classe": reservation.classe,
        "montant_fcfa": reservation.montant_fcfa,
        "agence_nom": voyage.bus.agence.nom,
        "bus_immatriculation": voyage.bus.numero_immatriculation,
        "conducteur": voyage.conducteur,
        "date_reservation": reservation.date_reservation.strftime("%d/%m/%Y %H:%M"),
        "qr_code_b64": generer_qr_code_base64(qr_data),
        "statut": reservation.statut,
    }
