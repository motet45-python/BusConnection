"""
recherche_trajet.py
Algorithme BFS (Breadth-First Search) pour la recherche de trajets
avec correspondances entre villes.
Ex : Maroua → Douala via Ngaoundéré
"""

from collections import deque
from models import Trajet


def construire_graphe() -> dict:
    """
    Construit un graphe orienté {ville: [(ville_voisine, trajet_id, prix_min, duree)]}
    à partir des trajets actifs en base.
    """
    graphe = {}
    trajets = Trajet.query.filter_by(actif=True).all()

    for t in trajets:
        if t.ville_depart not in graphe:
            graphe[t.ville_depart] = []
        graphe[t.ville_depart].append({
            "destination": t.ville_arrivee,
            "trajet_id": t.id,
            "prix_classique": t.prix_classique_fcfa,
            "prix_vip": t.prix_vip_fcfa,
            "duree_h": t.duree_h,
        })

    return graphe


def rechercher_itineraires(depart: str, arrivee: str, max_correspondances: int = 2) -> list:
    """
    Recherche tous les itinéraires possibles entre deux villes via BFS.
    Retourne une liste de chemins, chaque chemin étant une liste de segments.
    Un segment = dict avec ville_depart, ville_arrivee, trajet_id, prix, duree.
    Limite à max_correspondances correspondances pour éviter les boucles infinies.
    """
    graphe = construire_graphe()
    resultats = []

    # File BFS : (ville_courante, chemin_parcouru, villes_visitées)
    file = deque()
    file.append((depart, [], set([depart])))

    while file:
        ville_courante, chemin, villes_visitees = file.popleft()

        # On dépasse la limite de correspondances
        if len(chemin) > max_correspondances + 1:
            continue

        voisins = graphe.get(ville_courante, [])
        for segment in voisins:
            dest = segment["destination"]

            if dest in villes_visitees:
                continue  # éviter les cycles

            nouveau_chemin = chemin + [segment]

            if dest == arrivee:
                resultats.append(_enrichir_chemin(nouveau_chemin))
            else:
                file.append((dest, nouveau_chemin, villes_visitees | {dest}))

    # Trier par durée totale croissante
    resultats.sort(key=lambda c: c["duree_totale_h"])
    return resultats


def _enrichir_chemin(chemin: list) -> dict:
    """
    Calcule les métriques agrégées d'un itinéraire (durée totale, prix total).
    """
    duree_totale = sum(s["duree_h"] for s in chemin)
    prix_classique_total = sum(s["prix_classique"] for s in chemin)
    prix_vip_total = sum(s["prix_vip"] for s in chemin)

    villes = [chemin[0]["ville_depart"]] + [s["ville_arrivee"] for s in chemin]

    return {
        "segments": chemin,
        "villes": villes,
        "nb_correspondances": len(chemin) - 1,
        "duree_totale_h": round(duree_totale, 1),
        "prix_classique_total": prix_classique_total,
        "prix_vip_total": prix_vip_total,
        "label": " → ".join(villes),
    }


def get_villes_disponibles() -> list:
    """
    Retourne la liste des villes de départ disponibles dans la base.
    """
    trajets = Trajet.query.filter_by(actif=True).all()
    villes = set()
    for t in trajets:
        villes.add(t.ville_depart)
        villes.add(t.ville_arrivee)
    return sorted(villes)
