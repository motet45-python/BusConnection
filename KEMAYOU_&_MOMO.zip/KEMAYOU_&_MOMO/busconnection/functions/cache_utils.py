"""
cache_utils.py
Utilitaires de mise en cache (Flask-Caching) pour les trajets et disponibilités.
"""

from extensions import cache
from models import Trajet, Voyage
from datetime import datetime


def get_trajets_caches():
    """
    Retourne la liste des trajets actifs depuis le cache.
    Si absent du cache, requête la base et met en cache pour 5 min.
    """
    cle = "trajets_actifs"
    trajets = cache.get(cle)

    if trajets is None:
        trajets_db = Trajet.query.filter_by(actif=True).all()
        trajets = [
            {
                "id": t.id,
                "ville_depart": t.ville_depart,
                "ville_arrivee": t.ville_arrivee,
                "duree_h": t.duree_h,
                "prix_classique_fcfa": t.prix_classique_fcfa,
                "prix_vip_fcfa": t.prix_vip_fcfa,
            }
            for t in trajets_db
        ]
        cache.set(cle, trajets, timeout=300)

    return trajets


def get_voyages_disponibles_caches(depart: str, arrivee: str, date_recherche=None):
    """
    Retourne les voyages disponibles (places > 0) pour un trajet et une date donnés.
    Mis en cache 2 minutes (données plus volatiles).
    """
    date_str = date_recherche.strftime("%Y%m%d") if date_recherche else "all"
    cle = f"voyages_{depart}_{arrivee}_{date_str}"

    voyages = cache.get(cle)
    if voyages is None:
        query = (
            Voyage.query
            .join(Voyage.trajet)
            .filter(
                Trajet.ville_depart == depart,
                Trajet.ville_arrivee == arrivee,
                Voyage.places_disponibles > 0,
                Voyage.statut == "planifie",
                Voyage.date_heure_depart >= datetime.utcnow(),
            )
            .order_by(Voyage.date_heure_depart)
        )

        if date_recherche:
            debut = datetime.combine(date_recherche, datetime.min.time())
            fin = datetime.combine(date_recherche, datetime.max.time())
            query = query.filter(Voyage.date_heure_depart.between(debut, fin))

        voyages_db = query.all()
        voyages = [
            {
                "id": v.id,
                "trajet": f"{v.trajet.ville_depart} → {v.trajet.ville_arrivee}",
                "date_heure_depart": v.date_heure_depart.strftime("%d/%m/%Y %H:%M"),
                "places_disponibles": v.places_disponibles,
                "bus_type": v.bus.type,
                "agence": v.bus.agence.nom,
                "prix_classique": v.trajet.prix_classique_fcfa,
                "prix_vip": v.trajet.prix_vip_fcfa,
                "conducteur": v.conducteur,
            }
            for v in voyages_db
        ]
        cache.set(cle, voyages, timeout=120)

    return voyages


def invalider_cache_voyage(depart: str = None, arrivee: str = None):
    """
    Invalide le cache des voyages pour forcer un rechargement.
    Appelé après une réservation ou annulation.
    """
    cache.delete("trajets_actifs")
    if depart and arrivee:
        # On invalide toutes les clés pour ce couple de villes
        for date_str in ["all"]:
            cache.delete(f"voyages_{depart}_{arrivee}_{date_str}")
