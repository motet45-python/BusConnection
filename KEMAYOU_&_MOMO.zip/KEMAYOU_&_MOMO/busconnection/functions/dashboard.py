"""
dashboard.py
Fonctions de calcul des métriques pour le tableau de bord agence.
"""

from datetime import datetime, date, timedelta
from sqlalchemy import func
from extensions import db
from models import Voyage, Reservation, Trajet, Bus


def get_recettes_journalieres(agence_id: int, jour: date = None) -> int:
    """
    Calcule les recettes totales (FCFA) d'une agence pour un jour donné.
    Par défaut : aujourd'hui.
    """
    if jour is None:
        jour = date.today()

    debut = datetime.combine(jour, datetime.min.time())
    fin = datetime.combine(jour, datetime.max.time())

    total = (
        db.session.query(func.sum(Reservation.montant_fcfa))
        .join(Voyage)
        .join(Bus)
        .filter(
            Bus.agence_id == agence_id,
            Reservation.statut == "confirme",
            Reservation.date_reservation.between(debut, fin),
        )
        .scalar()
    )
    return total or 0


def get_taux_remplissage_par_voyage(agence_id: int) -> list:
    """
    Retourne le taux de remplissage de chaque voyage actif pour une agence.
    """
    voyages = (
        Voyage.query
        .join(Bus)
        .filter(Bus.agence_id == agence_id, Voyage.statut == "planifie")
        .all()
    )

    resultats = []
    for v in voyages:
        taux = v.taux_remplissage()
        resultats.append({
            "voyage_id": v.id,
            "trajet": f"{v.trajet.ville_depart} → {v.trajet.ville_arrivee}",
            "date_depart": v.date_heure_depart.strftime("%d/%m/%Y %H:%M"),
            "taux": taux,
            "places_total": v.bus.capacite,
            "places_dispo": v.places_disponibles,
        })

    resultats.sort(key=lambda x: x["taux"], reverse=True)
    return resultats


def get_trajets_populaires(agence_id: int, limite: int = 5) -> list:
    """
    Retourne les trajets les plus réservés pour une agence (top N).
    """
    resultats = (
        db.session.query(
            Trajet.ville_depart,
            Trajet.ville_arrivee,
            func.count(Reservation.id).label("nb_reservations"),
        )
        .join(Voyage, Voyage.trajet_id == Trajet.id)
        .join(Bus, Bus.id == Voyage.bus_id)
        .join(Reservation, Reservation.voyage_id == Voyage.id)
        .filter(Bus.agence_id == agence_id, Reservation.statut == "confirme")
        .group_by(Trajet.ville_depart, Trajet.ville_arrivee)
        .order_by(func.count(Reservation.id).desc())
        .limit(limite)
        .all()
    )

    return [
        {
            "trajet": f"{r.ville_depart} → {r.ville_arrivee}",
            "nb_reservations": r.nb_reservations,
        }
        for r in resultats
    ]


def get_recettes_semaine(agence_id: int) -> list:
    """
    Retourne les recettes par jour sur les 7 derniers jours.
    Utile pour le graphique du tableau de bord.
    """
    today = date.today()
    data = []

    for i in range(6, -1, -1):
        jour = today - timedelta(days=i)
        recettes = get_recettes_journalieres(agence_id, jour)
        data.append({"jour": jour.strftime("%d/%m"), "recettes": recettes})

    return data


def get_stats_globales(agence_id: int) -> dict:
    """
    Statistiques globales pour la carte de synthèse du dashboard.
    """
    total_reservations = (
        db.session.query(func.count(Reservation.id))
        .join(Voyage)
        .join(Bus)
        .filter(Bus.agence_id == agence_id, Reservation.statut == "confirme")
        .scalar()
        or 0
    )

    total_recettes = (
        db.session.query(func.sum(Reservation.montant_fcfa))
        .join(Voyage)
        .join(Bus)
        .filter(Bus.agence_id == agence_id, Reservation.statut == "confirme")
        .scalar()
        or 0
    )

    voyages_planifies = (
        Voyage.query.join(Bus)
        .filter(Bus.agence_id == agence_id, Voyage.statut == "planifie")
        .count()
    )

    return {
        "total_reservations": total_reservations,
        "total_recettes": total_recettes,
        "voyages_planifies": voyages_planifies,
        "recettes_aujourd_hui": get_recettes_journalieres(agence_id),
    }
