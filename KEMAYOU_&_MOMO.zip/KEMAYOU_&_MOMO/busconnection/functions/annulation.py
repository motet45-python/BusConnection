"""
annulation.py
Gestion des annulations de réservation avec politique de remboursement.
Politique :
  - Annulation > 48h avant le départ  → remboursement 100%
  - Annulation entre 24h et 48h       → remboursement 50%
  - Annulation < 24h avant le départ  → remboursement 0%
"""

from datetime import datetime, timezone
from extensions import db
from models import Reservation, ListeAttente
from functions.disponibilite import liberer_place


def calculer_remboursement(reservation) -> dict:
    """
    Calcule le montant remboursable selon la politique d'annulation.
    Retourne un dict avec : montant_rembourse, pourcentage, message.
    """
    now = datetime.utcnow()
    depart = reservation.voyage.date_heure_depart
    delta_heures = (depart - now).total_seconds() / 3600

    if delta_heures > 48:
        pourcentage = 100
        message = "Remboursement intégral (annulation > 48h avant le départ)"
    elif delta_heures > 24:
        pourcentage = 50
        message = "Remboursement à 50% (annulation entre 24h et 48h avant le départ)"
    else:
        pourcentage = 0
        message = "Aucun remboursement (annulation < 24h avant le départ)"

    montant_rembourse = int(reservation.montant_fcfa * pourcentage / 100)
    return {
        "pourcentage": pourcentage,
        "montant_rembourse": montant_rembourse,
        "message": message,
        "heures_restantes": round(delta_heures, 1),
    }


def annuler_reservation(reservation_id: int) -> tuple[bool, str, dict]:
    """
    Annule une réservation :
      1. Calcule le remboursement dû
      2. Passe le statut de la réservation à 'annule'
      3. Libère la place sur le voyage
      4. Notifie la liste d'attente si applicable
    Retourne (succès: bool, message: str, info_remboursement: dict).
    """
    reservation = Reservation.query.get(reservation_id)
    if not reservation:
        return False, "Réservation introuvable.", {}

    if reservation.statut == "annule":
        return False, "Cette réservation est déjà annulée.", {}

    info = calculer_remboursement(reservation)

    reservation.statut = "annule"
    db.session.commit()

    liberer_place(reservation.voyage_id)

    _notifier_liste_attente(reservation.voyage_id)

    return True, info["message"], info


def _notifier_liste_attente(voyage_id: int):
    """
    Vérifie s'il existe des personnes en liste d'attente pour ce voyage
    et marque la première comme "notifiée" (à connecter à un système email/SMS).
    """
    attente = (
        ListeAttente.query
        .filter_by(voyage_id=voyage_id, notifie=False)
        .order_by(ListeAttente.date_inscription)
        .first()
    )
    if attente:
        attente.notifie = True
        db.session.commit()
        # TODO : envoyer un SMS/email à attente.passager_telephone
